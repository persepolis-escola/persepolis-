# Persepolis Escola Livre — site institucional para Vercel

Projeto estático independente, em português e inglês, com identidade afrofuturista, 20 fotografias enviadas pela Persepolis e nova capa de conserto de computadores.

## Conteúdo

- `index.html` — páginas e seções do site.
- `styles.css` — identidade visual responsiva.
- `app.js` — interações sem dependências externas (menu, idioma, ciclo dos equipamentos, produtos, galeria, territórios, simulador e contato).
- `assets/hero.webp` — imagem horizontal da oficina.
- `assets/fotos/*.webp` — as 20 fotos reais enviadas na conversa.
- `assets/originais/*` — cópia dos arquivos originais da coleção de imagens.
- `assets/brand/*` — marca vetorial da Persepolis usada no projeto.
- `vercel.json` — configuração para hospedagem estática na Vercel.

## Publicar na Vercel

**Via terminal no computador (mais simples para a pasta pronta):**

1. Descompacte o ZIP.
2. Entre na pasta que contém `index.html`.
3. Execute `npx vercel login`.
4. Execute `npx vercel --prod` e confirme a criação do projeto, com diretório raiz `.`.
5. Após o endereço `*.vercel.app` funcionar, vá a Vercel > projeto > Settings > Domains para configurar seu domínio.

**Via GitHub:** crie um repositório com os arquivos desta pasta, entre em https://vercel.com/new, importe o repositório e publique como projeto estático (framework: Other, sem build, raiz: `/`).

## Atenção ao domínio

`persepolisescola.com.br` já é utilizado por outro site. Preserve o site e o DNS anteriores antes de apontar o domínio para a Vercel. Configure `www` e o domínio raiz de acordo com as instruções específicas exibidas pelo painel da Vercel. Não altere os registros de e-mail (MX, SPF, DKIM) nem substitua toda a zona DNS sem necessidade.

## Notas técnicas

- Site estático. O formulário **não coleta nem armazena dados**: apenas prepara uma mensagem por `mailto:` para `miro@persepolislab.com.br`, que o visitante deve enviar no seu cliente de e-mail.
- O simulador é ilustrativo. Não representa indicadores ambientais auditados ou resultados obtidos.
- Os três links para PDFs apontam para os arquivos hospedados no institucional original. Para autonomia completa, os PDFs também devem ser copiados para `assets/`, se você possuir os arquivos.
- Google Fonts é um recurso externo opcional; o site possui fontes alternativas caso não carregue.
- Essa versão estática foi reconstruída com os conteúdos, fotografias e interações da versão anterior. **Não é exportação integral do código fonte proprietário do Floot.**
